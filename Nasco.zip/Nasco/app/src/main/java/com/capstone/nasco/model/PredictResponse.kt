package com.capstone.nasco.model

import com.google.gson.annotations.SerializedName

data class PredictResponse(

	@field:SerializedName("confidence")
	val confidence: Any,

	@field:SerializedName("prediction")
	val prediction: String,

	@field:SerializedName("description")
	val description: String
)
